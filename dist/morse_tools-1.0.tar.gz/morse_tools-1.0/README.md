# morse-tools

## Installation
```
$ python3 -m pip install morse-tools
```

## How to use
```
$ morse-tools -h
```